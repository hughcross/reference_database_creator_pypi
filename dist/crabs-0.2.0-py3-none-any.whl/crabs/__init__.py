
import sys 

__version__ = "0.2.0"

__author__ = "Gert-Jan Jeunen"


